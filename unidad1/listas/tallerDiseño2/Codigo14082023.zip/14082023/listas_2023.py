#Clase Nodo Simple
class NodoSimple:
    #Constructor
    def __init__(self, dato_usuario) -> None:
        self.info = dato_usuario
        self.siguiente  = None
    #Str
    def __str__(self) -> str:
        return str(self.info)
#Clase Lista Simple
class ListaSimple:
    def __init__(self) -> None:
        self.nodoInicial = None
    #Adicionar al inicio
    def adicionarAlInicio(self, dato_nuevo):
        nodoNuevo = NodoSimple(dato_nuevo)
        if self.nodoInicial == None: #Si la lista esta vacia
            self.nodoInicial = nodoNuevo #Se hace el primer nodo
        else:
            #La lista ya tiene al menos un nodo
            nodoNuevo.siguiente = self.nodoInicial
            self.nodoInicial = nodoNuevo #Actualizar el nodo inicial
    #Recorrido
    def __str__(self) -> str:
        recorrido = ""
        nodoActual = self.nodoInicial
        while nodoActual != None: #Mientras el nodo exista (lista sin acabar)
            recorrido += str(nodoActual.info) + " "
            nodoActual = nodoActual.siguiente
        return recorrido

