#Prueba
from listas_2023 import ListaSimple
lista01 = ListaSimple()
print("Nodo inicial:",lista01.nodoInicial)
lista01.adicionarAlInicio("Casa")
print("Nodo inicial:",lista01.nodoInicial)
lista01.adicionarAlInicio("Python")
print("Nodo inicial:",lista01.nodoInicial)
print("Nodo siguiente:",lista01.nodoInicial.siguiente)
print("Lista:",lista01)
for i in range(1, 11):
    lista01.adicionarAlInicio(i)
print("Lista:",lista01)
lista_prueba = [1, 2, 3, 4, 5]
lista01.adicionarAlInicio(lista_prueba)
print("Lista:",lista01)